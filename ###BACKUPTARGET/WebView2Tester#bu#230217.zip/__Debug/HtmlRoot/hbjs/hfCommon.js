//======================================================================
// # hfnum: 넘버 관련 모듈
//======================================================================
/**
 * 넘버가 맞는지 확인
 * @param {*} tv
 * @returns
 */
const IsNumber = (tv) => {
    return typeof tv === 'number';
};


/**
 * 넘버가 아닌지 확인
 * @param {*} tv
 * @returns
 */
const NotNumber = (tv) => {
    return typeof tv !== 'number';
};


/**
 * 넘버가 실수인지 확인
 * @param {*} tv
 * @returns
 */
const IsFloat = (tv) => {
    return (tv % 1) !== 0;
};


/**
 * 넘버가 음수인지 확인
 * @param {*} tv
 * @returns
 */
const IsMinus = (tv) => {
    return tv < 0;
};


/**
 * 난수 만들기 0~n
 * @param {*} tv
 * @returns
 */
const Random = (tv) => {
    return Math.round(Math.random() * (tv - 1));
};


/**
 * 난수 만들기 min~max
 * @param {*} min
 * @param {*} max
 * @returns
 */
const RandRange = (min, max) => {
    return min + Math.round(Math.random() * (max - min));
};


/**
 * 넘버가 홀수인지 확인
 * @param {*} tv
 * @returns
 */
const IsOdd = (tv) => {
    return (tv % 2) > 0;
};


/**
 * 넘버가 짝수인지 확인
 * @param {*} tv
 * @returns
 */
const IsEven = (tv) => {
    return (tv % 2) === 0;
};



export const hfnum = Object.seal({
    IsFloat,
    IsMinus,
    Random,
    RandRange,
    IsOdd,
    IsEven
});
//======================================================================




//======================================================================
// # hfstr: 문자열 관련 모듈
//======================================================================
/**
 * 문자열 유효성 확인
 * @param {*} tstr
 * @returns
 */
const IsStr = (tstr) => {
    if (typeof tstr === 'string')
        return tstr.trim() !== '';
    else
        return false;
};


/**
 * 이름에서 마지막 번호 확인
 * @param {*} tstr
 * @param {*} token
 * @returns
 */
const GetLastNum = (tstr, token = '_') => {
    const ti = tstr.lastIndexOf(token) + 1;
    return ~~tstr.substr(ti);
};


/**
 * 문자열 >> ArrayBuffer 변환
 * @param {*} tstr
 * @returns
 */
const Str2Ab = (tstr) => {
    const tl = tstr.length;

    let tab = new Uint16Array(new ArrayBuffer(tl * 2));
    for (let i = 0; i < tl; i++) {
        tab[i] = tstr.charCodeAt(i);
    }

    return tab;
};


/**
 * ArrayBuffer >> 문자열 변환
 * @param {*} tab
 * @returns
 */
const Ab2Str = (tab) => {
    return String.fromCharCode.apply(null, tab);
};



export const hfstr = Object.seal({
    IsStr,
    GetLastNum,
    Str2Ab,
    Ab2Str
});
//======================================================================




//======================================================================
// # hfarr: 배열 관련 모듈
//======================================================================
/**
 * 배열객체 유효성 확인
 * @param {*} tarr
 * @returns
 */
const IsArr = (tarr) => {
    return Array.isArray(tarr) && (tarr.length > 0);
    // if (!Array.isArray(tarr)) return false;
    // return (tarr !== null) && (tarr.length > 0);
};


/**
 * 배열에 요소 확인
 * @param {*} tarr
 * @param {*} te
 * @returns
 */
const IsContains = (tarr, te) => {
    if (IsArr(tarr) === false) return false;


    let tb = false;

    const tl = tarr.length
    for (let i = 0; i < tl; i++) {
        if (tarr[i] === te) {
            tb = true;
            break;
        }
    }

    return tb;
};


/**
 * 배열 섞기
 * @param {*} tarr
 * @returns
 */
const Shuffle = (tarr) => {
    if (IsArr(tarr) === false) return;


    const tl = tarr.length;
    for (let i = 0; i < tl; i++) {
        let te = tarr[i];
        let ti = hfnum.RandRange(0, tl - 1);
        tarr[i] = tarr[ti];
        tarr[ti] = te;
    }
};


/**
 * 배열 복사
 * @param {*} tarr
 * @returns
 */
const Copy = (tarr) => {
    if (IsArr(tarr) === false) return null;

    return tarr.slice();
};



export const hfarr = Object.seal({
    IsArr,
    IsContains,
    Shuffle,
    Copy
});
//======================================================================





