'use strict';
import { hfnum, hfstr, hfarr } from "./hbjs/hfCommon.js";
import { hfCountTask } from "./hbjs/hfCountTask.js";



//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// console.log(hfnum, hfstr, hfarr);
// console.log(hfnum.is_even(78));
// for (let i = 0; i < 99; i++) {
//     console.log(hfnum.randRange(33, 100));
//     console.log(hfnum.randRange(33, 100));
//     console.log(hfnum.randRange(33, 100));
// }



//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// console.log(hfCountTask);
// console.log(new hfCountTask());

// const _ct1 = new hfCountTask(15, 35, 1);
// console.log(_ct1);
// console.log(_ct1.count);
// while (_ct1.next()) {
//     console.log(_ct1.count);
// }

// console.log(_ct1.count);
// while (_ct1.prev()) {
//     console.log(_ct1.count);
// }



// const _dcont = document.getElementById('_dcontainer');
// _dcont.innerHTML = `
//     <iframe class="c_ifr" src="./TestPages/Tester__hfCommon.html"></iframe>
//     <iframe class="c_ifr" src="./TestPages/Tester__hfCountTask.html"></iframe>
//     <iframe class="c_ifr" src="./TestPages/Tester__hfTween.html"></iframe>
// `;

const _dcontainer = document.getElementById('_dcontainer');
const _dfooter = document.getElementById('_dfooter');

const tca = _dcontainer.children;
if ((tca !== null) && (tca.length > 0)) {
    let tes = '';
    for (const tc of tca) {
        let tnm = tc.getAttribute('src');
        const bi = 20;
        const ei = tnm.lastIndexOf('.html');
        tnm = tnm.substring(bi, ei);
        tes += `<input class="c_bt" type="button" value="${ tnm }"></input>`;
    }
    _dfooter.innerHTML = tes;
}



