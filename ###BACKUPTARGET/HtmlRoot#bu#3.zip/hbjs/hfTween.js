//======================================================================
// # hfTween:
//======================================================================
class hfTween extends Event {
    static ET_UPDATE = 'update';
    static ET_END = 'end';

    constructor(current = 0, duration = 36, ease = null) {
        this.#running = false;
        this.#begin = current;
        this.#change = current;
        this.#current = current;
        this.#time = 0;
        this.#duration duration;
        this.#ease = ease ?? ;
    }

    #running = false;
    get Running() {
        return this.#running;
    }

    #begin = 0.0;
    get Begin() {
        return this.#begin;
    }

    #change = 0.0;
    get Change() {
        return this.#change;
    }

    #current = 0.0;
    get Current() {
        return this.#current;
    }

    #time = 0;
    get Time() {
        return this.#time;
    }

    #duration = 0;
    get Duration() {
        return this.#duration;
    }

    #ease = 0;
    get Ease() {
        return this.#ease;
    }


    #fid = -1;
    #EnterFrame() {

    }


    To(change) {
        if (this.#running === true)
            this.Stop();

        this.#time = 0;
        this.#begin = this.#current;
        this.#change = change - this.#begin;
        this.#fid = requestAnimationFrame(this.#EnterFrame);
    }

    Stop() {
        if (this.#running === true) {

            this.#running = false;
        }
    }

}

export { hfTween };
//======================================================================





