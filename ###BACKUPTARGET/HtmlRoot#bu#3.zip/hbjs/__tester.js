const fn_test = () => {
    console.log('>>>: ' + window);
    console.log('개발자입니다.');
};

export default {
    fn_test
};