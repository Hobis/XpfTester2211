//======================================================================
// # hfCountTask: 카운트 연산하기
//======================================================================
class hfCountTask {
    #countStart = 0;
    #countEnd = 0;
    #plusValue = 0;
    #count = 0;

    constructor(countStart = 1, countEnd = 10, plusValue = 1) {
        this.#countStart = countStart;
        this.#countEnd = countEnd;
        this.#plusValue = plusValue;
        this.#count = countStart;
    }


    get countStart() {
        return this.#countStart;
    }

    get countEnd() {
        return this.#countEnd;
    }

    get plusValue() {
        return this.#plusValue;
    }

    get count() {
        return this.#count;
    }


    prev() {
        const tc = this.#count - this.#plusValue;
        if (tc < this.#countStart)
            return false;
        else {
            this.#count = tc;
            return true;
        }
    }

    next() {
        const tc = this.#count + this.#plusValue;
        if (tc > this.#countEnd)
            return false;
        else {
            this.#count = tc;
            return true;
        }
    }


    reset() {
        this.#count = this.#countStart;
    }

    resetEnd() {
        this.#count = this.#countEnd;
    }
}

export { hfCountTask };
//======================================================================





