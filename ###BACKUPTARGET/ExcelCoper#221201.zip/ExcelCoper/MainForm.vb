﻿#Region "~~~~~~~~~~ 00) Imports"
Imports Microsoft.VisualBasic
Imports System
Imports System.Collections
Imports System.Collections.Generic
Imports System.Data
Imports System.Drawing
Imports System.Diagnostics
Imports System.Windows.Forms
Imports System.Linq
Imports System.Xml.Linq
Imports System.Text
Imports System.Threading.Tasks
#End Region



Public NotInheritable Class MainForm
    Public Sub New()
        ' 디자이너에서 이 호출이 필요합니다.
        InitializeComponent()

        ' InitializeComponent() 호출 뒤에 초기화 코드를 추가하세요.

    End Sub


    ''' <summary>
    ''' 온로드
    ''' </summary>
    ''' <param name="tea"></param>
    Protected Overrides Sub OnLoad(tea As EventArgs)
        MyBase.OnLoad(tea)
        Text = [GetType]().Namespace
        m_txbr.Clear()
        m_txr.Text = ","
        AddHandler m_btnClear.Click, AddressOf _ClickHandler_Clear
        AddHandler m_btnConvert.Click, AddressOf _ClickHandler_Convert
        AddHandler m_btnCopy.Click, AddressOf _ClickHandler_Copy

        'Dim txa As String = "     d""dd"
        'Dim txb As String = _GetMakeString(txa)
    End Sub


    Private Function _GetSeperater() As String
        Return m_txr.Text
    End Function


    Private Function _GetMakeString(str As String, Optional tcx As Char = """"c) As String
        If String.IsNullOrWhiteSpace(str) Then
            Return String.Empty
        End If
        Dim tsb As New StringBuilder()
        tsb.Append(tcx)
        For Each tc As Char In str
            If tc = tcx Then
                tsb.Append(tcx & tcx)
            Else
                tsb.Append(tc)
            End If
        Next
        tsb.Append(tcx)
        Return tsb.ToString()
    End Function



    Private Sub _ClickHandler_Clear(tsd As Object, tea As EventArgs)
        m_txbr.Clear()
    End Sub


    Private Sub _ClickHandler_Convert(tsd As Object, tea As EventArgs)
        If Clipboard.ContainsText() Then
            Dim alltxt As String = Clipboard.GetText()
            Dim tlsa() As String = alltxt.Split({vbNewLine}, StringSplitOptions.None)
            Dim sep As String = _GetSeperater()
            Dim tsb As New StringBuilder()
            For Each tls As String In tlsa
                Dim tma() As String = tls.Split({vbTab}, StringSplitOptions.None)
                Dim bFirst As Boolean = True
                For Each tm As String In tma
                    If bFirst Then
                        Dim ty As String = _GetMakeString(tm)
                        tsb.Append(ty)
                        bFirst = False
                    Else
                        Dim ty As String = sep & _GetMakeString(tm)
                        tsb.Append(ty)
                    End If
                Next
                tsb.AppendLine()
            Next
            m_txbr.Text = tsb.ToString()
        End If
    End Sub


    Private Sub _ClickHandler_Copy(tsd As Object, tea As EventArgs)
        Clipboard.SetText(m_txbr.Text)
    End Sub

End Class
