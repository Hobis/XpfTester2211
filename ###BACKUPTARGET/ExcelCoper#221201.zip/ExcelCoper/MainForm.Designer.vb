﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class MainForm
    Inherits System.Windows.Forms.Form

    'Form은 Dispose를 재정의하여 구성 요소 목록을 정리합니다.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows Form 디자이너에 필요합니다.
    Private components As System.ComponentModel.IContainer

    '참고: 다음 프로시저는 Windows Form 디자이너에 필요합니다.
    '수정하려면 Windows Form 디자이너를 사용하십시오.  
    '코드 편집기에서는 수정하지 마세요.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.m_txbr = New System.Windows.Forms.TextBox()
        Me.m_btnConvert = New System.Windows.Forms.Button()
        Me.m_btnClear = New System.Windows.Forms.Button()
        Me.m_btnCopy = New System.Windows.Forms.Button()
        Me.m_txr = New System.Windows.Forms.TextBox()
        Me.SuspendLayout()
        '
        'm_txbr
        '
        Me.m_txbr.Location = New System.Drawing.Point(12, 12)
        Me.m_txbr.Multiline = True
        Me.m_txbr.Name = "m_txbr"
        Me.m_txbr.ScrollBars = System.Windows.Forms.ScrollBars.Both
        Me.m_txbr.Size = New System.Drawing.Size(576, 566)
        Me.m_txbr.TabIndex = 0
        Me.m_txbr.WordWrap = False
        '
        'm_btnConvert
        '
        Me.m_btnConvert.Cursor = System.Windows.Forms.Cursors.Hand
        Me.m_btnConvert.Location = New System.Drawing.Point(438, 613)
        Me.m_btnConvert.Name = "m_btnConvert"
        Me.m_btnConvert.Size = New System.Drawing.Size(150, 75)
        Me.m_btnConvert.TabIndex = 4
        Me.m_btnConvert.Text = "변환하기"
        Me.m_btnConvert.UseVisualStyleBackColor = True
        '
        'm_btnClear
        '
        Me.m_btnClear.Cursor = System.Windows.Forms.Cursors.Hand
        Me.m_btnClear.Location = New System.Drawing.Point(126, 613)
        Me.m_btnClear.Name = "m_btnClear"
        Me.m_btnClear.Size = New System.Drawing.Size(150, 75)
        Me.m_btnClear.TabIndex = 2
        Me.m_btnClear.Text = "비우기"
        Me.m_btnClear.UseVisualStyleBackColor = True
        '
        'm_btnCopy
        '
        Me.m_btnCopy.Cursor = System.Windows.Forms.Cursors.Hand
        Me.m_btnCopy.Location = New System.Drawing.Point(282, 613)
        Me.m_btnCopy.Name = "m_btnCopy"
        Me.m_btnCopy.Size = New System.Drawing.Size(150, 75)
        Me.m_btnCopy.TabIndex = 3
        Me.m_btnCopy.Text = "복사하기"
        Me.m_btnCopy.UseVisualStyleBackColor = True
        '
        'm_txr
        '
        Me.m_txr.Location = New System.Drawing.Point(12, 584)
        Me.m_txr.Name = "m_txr"
        Me.m_txr.Size = New System.Drawing.Size(576, 23)
        Me.m_txr.TabIndex = 1
        Me.m_txr.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'MainForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(600, 700)
        Me.Controls.Add(Me.m_txr)
        Me.Controls.Add(Me.m_btnCopy)
        Me.Controls.Add(Me.m_btnClear)
        Me.Controls.Add(Me.m_btnConvert)
        Me.Controls.Add(Me.m_txbr)
        Me.Font = New System.Drawing.Font("맑은 고딕", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.MaximizeBox = False
        Me.Name = "MainForm"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents m_txbr As System.Windows.Forms.TextBox
    Friend WithEvents m_btnConvert As System.Windows.Forms.Button
    Friend WithEvents m_btnClear As System.Windows.Forms.Button
    Friend WithEvents m_btnCopy As System.Windows.Forms.Button
    Friend WithEvents m_txr As System.Windows.Forms.TextBox
End Class
