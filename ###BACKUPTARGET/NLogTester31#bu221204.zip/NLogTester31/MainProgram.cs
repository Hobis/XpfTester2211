﻿using NLog;
using NLog.Config;
using NLogTester31.Properties;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;




namespace NLogTester31
{
    public static class MainProgram
    {
        // 로거 인스턴서 선언
        private static readonly Logger Logger = LogManager.GetCurrentClassLogger();


        //
        //https://nlog-project.org/config/
        //^\[#BEGIN \d\d\d\d-\d\d-\d\d \d\d\:\d\d\:\d\d\.\d\d\d\d\][\s\S]+?\[#END\]$
        //^\[#BEGIN \d{4}-\d{2}-\d{2} \d{2}\:\d{2}\:\d{2}\.\d{4}\][\s\S]+?\[#END\]$
        //^\[#BEGIN\|[A-z]+?\b\|\d{15}][\s\S]+?\[#END\]$
        //https://regexr.com/

        public static void Main(string[] args)
        {
            XmlLoggingConfiguration txlc = XmlLoggingConfiguration.CreateFromXmlString(Resources.NLogConfig);
            LogManager.Configuration = txlc;


            

            Action act = delegate { prWorkThread("박종명"); };
            act.BeginInvoke(null, null);
            act = delegate { prWorkThread("임헌진"); };
            act.BeginInvoke(null, null);
            act = delegate { prWorkThread("정희범"); };
            act.BeginInvoke(null, null);


            Thread.CurrentThread.Join();
        }


        private static void prWorkThread(string tnm)
        {
            while (true)
            {
                Logger.Debug(
                    string.Format("{{{{{{{{ {0} >> {1}",
                        tnm, DateTime.Now.ToString("yyMMddHHmmssfff"))
                    );
                Logger.Info(Resources.Data1);
                Logger.Info(Resources.Data1);
                Logger.Info(Resources.Data1);
                Logger.Info(Resources.Data1);
                Logger.Debug(
                    string.Format("}}}}}}}} {0}", tnm)
                    );
                Thread.Sleep(100);
            }

            //while (true)
            //{
            //    Logger.Debug("개발자 메세지");
            //    Logger.Info("개발자 메세지");
            //    Logger.Debug("개발자 메세지");
            //    Logger.Info(Resources.Data1);
            //    Logger.Info(Resources.Data1);
            //    Logger.Info(Resources.Data1);
            //    Logger.Info(Resources.Data1);
            //    Thread.Sleep(100);
            //}
        }

    }
}

