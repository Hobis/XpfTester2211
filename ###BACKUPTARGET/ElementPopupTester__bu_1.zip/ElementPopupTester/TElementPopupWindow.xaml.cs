﻿using DevExpress.Xpf.Core;
using System;
using System.ComponentModel;
using System.Windows;




namespace ElementPopupTester
{
    public sealed partial class TElementPopupWindow : ThemedWindow, IDisposable
    {
        #region [ 01 초기화 부분 ]
        private TElementPopupWindow()
        {
            InitializeComponent();
            ResizeMode = ResizeMode.CanResizeWithGrip;
            SizeToContent = SizeToContent.WidthAndHeight;
            WindowStartupLocation = WindowStartupLocation.CenterScreen;            
            Loaded += ThisLoaded;
            Result = MessageBoxResult.None;
        }

        protected override void OnContentRendered(EventArgs tea)
        {
            base.OnContentRendered(tea);
            SizeToContent = SizeToContent.Manual;
            MinWidth = ActualWidth;
            MinHeight = ActualHeight;
            Element.Width = double.NaN;
            Element.Height = double.NaN;
        }

        private void ThisLoaded(object tsd, RoutedEventArgs tea)
        {
            Loaded -= ThisLoaded;
            LoadedCall?.Invoke(this, tea);
            _btnOK.Click += _ButtonsClick;
            _btnYes.Click += _ButtonsClick;
            _btnNo.Click += _ButtonsClick;
            _btnCancel.Click += _ButtonsClick;
        }

        protected override void OnClosing(CancelEventArgs tea)
        {
            base.OnClosing(tea);
            //Result = MessageBoxResult.None;
        }

        public void Dispose()
        {
            if (Element == null) return;
            Element = null;
            LoadedCall = null;
            _btnOK.Click -= _ButtonsClick;
            _btnYes.Click -= _ButtonsClick;
            _btnNo.Click -= _ButtonsClick;
            _btnCancel.Click -= _ButtonsClick;
        }

        public MessageBoxResult Result { get; private set; }

        private FrameworkElement _element;
        public FrameworkElement Element
        {
            get { return _element; }
            private set
            {
                if (value == _element) return;
                _element = value;
                _brdc.Child = _element;
            }
        }

        private MessageBoxButton _buttons;
        public MessageBoxButton Buttons
        {
            get { return _buttons; }
            private set
            {
                _buttons = value;
                if (_buttons == MessageBoxButton.OK)
                {
                    _btnOK.Visibility = Visibility.Visible;
                    _btnCancel.Visibility = Visibility.Collapsed;
                    _btnYes.Visibility = Visibility.Collapsed;
                    _btnNo.Visibility = Visibility.Collapsed;
                }
                else if (_buttons == MessageBoxButton.OKCancel)
                {
                    _btnOK.Visibility = Visibility.Visible;
                    _btnCancel.Visibility = Visibility.Visible;
                    _btnYes.Visibility = Visibility.Collapsed;
                    _btnNo.Visibility = Visibility.Collapsed;
                }
                else if (_buttons == MessageBoxButton.YesNo)
                {
                    _btnOK.Visibility = Visibility.Collapsed;
                    _btnCancel.Visibility = Visibility.Collapsed;
                    _btnYes.Visibility = Visibility.Visible;
                    _btnNo.Visibility = Visibility.Visible;
                }
                else if (_buttons == MessageBoxButton.YesNoCancel)
                {
                    _btnOK.Visibility = Visibility.Collapsed;
                    _btnCancel.Visibility = Visibility.Visible;
                    _btnYes.Visibility = Visibility.Visible;
                    _btnNo.Visibility = Visibility.Visible;
                }
            }
        }

        public Action<TElementPopupWindow, RoutedEventArgs> LoadedCall { get; private set; }


        private void _ButtonsClick(object tsd, RoutedEventArgs tea)
        {
            if (tsd is SimpleButton btn)
            {
                if (btn.Name == "_btnOK")
                {
                    Result = MessageBoxResult.OK;
                    Close();
                }
                else if (btn.Name == "_btnYes")
                {
                    Result = MessageBoxResult.Yes;
                    Close();
                }
                else if (btn.Name == "_btnNo")
                {
                    Result = MessageBoxResult.No;
                    Close();
                }
                else if (btn.Name == "_btnCancel")
                {
                    Result = MessageBoxResult.Cancel;
                    Close();
                }
            }
        }
        #endregion




        public static MessageBoxResult ShowDialog(
            Window owner, string title, FrameworkElement element, MessageBoxButton buttons,
            Action<TElementPopupWindow> initCall = null,
            Action<TElementPopupWindow, RoutedEventArgs> loadedCall = null)
        {
            MessageBoxResult trv = MessageBoxResult.No;
            using (TElementPopupWindow twnd = new TElementPopupWindow())
            {
                twnd.Owner = owner;
                twnd.Title = title;
                twnd.Element = element;
                twnd.Buttons = buttons;
                twnd.ShowInTaskbar = false;
                initCall?.Invoke(twnd);
                twnd.LoadedCall = loadedCall;
                twnd.ShowDialog();
                trv = twnd.Result;
            }

            return trv;
        }


        public static MessageBoxResult ShowDialog(
            string title, FrameworkElement element, MessageBoxButton buttons = MessageBoxButton.YesNo)
        {
            Window owner = Application.Current?.MainWindow;
            return ShowDialog(owner, title, element, buttons);
        }

    }
}
