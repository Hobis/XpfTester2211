﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;
using DevExpress.Xpf.Core;




namespace ElementPopupTester
{
    public sealed partial class TesterWindow : ThemedWindow
    {
        public TesterWindow()
        {
            InitializeComponent();
            ResizeMode = ResizeMode.CanResizeWithGrip;
            SizeToContent = SizeToContent.WidthAndHeight;
            WindowStartupLocation = WindowStartupLocation.CenterScreen;
            SnapsToDevicePixels = true;
            _pnlrt.Width = 500;
            _pnlrt.Height = 300;
            Loaded += ppLoaded;
        }

        protected override void OnContentRendered(EventArgs tea)
        {
            base.OnContentRendered(tea);
            SizeToContent = SizeToContent.Manual;
            MinWidth = ActualWidth;
            MinHeight = ActualHeight;
            _pnlrt.Width = double.NaN;
            _pnlrt.Height = double.NaN;
        }

        private void ppLoaded(object tsd, RoutedEventArgs tea)
        {
            Loaded -= ppLoaded;
            _btn31.Click += delegate
            {
                TextBlock txb = new TextBlock();
                txb.Background = Brushes.DarkOrange;
                txb.FontSize = 56;
                txb.Text = "박종명 마운드";
                txb.Width = 400;
                txb.Height = 250;
                //MessageBoxButton buttons = MessageBoxButton.OK;
                //MessageBoxButton buttons = MessageBoxButton.OKCancel;
                //MessageBoxButton buttons = MessageBoxButton.YesNo;
                MessageBoxButton buttons = MessageBoxButton.OK;
                var tx1 = TElementPopupWindow.ShowDialog("타이틀", txb, buttons);
                MessageBox.Show(tx1.ToString());
            };
            _btn32.Click += delegate
            {
                TextBlock txb = new TextBlock();
                txb.Background = Brushes.DarkOrange;
                txb.FontSize = 56;
                txb.Text = "박종명 마운드";
                txb.Width = 400;
                txb.Height = 250;
                //MessageBoxButton buttons = MessageBoxButton.OK;
                //MessageBoxButton buttons = MessageBoxButton.OKCancel;
                //MessageBoxButton buttons = MessageBoxButton.YesNo;
                MessageBoxButton buttons = MessageBoxButton.OKCancel;
                var tx1 = TElementPopupWindow.ShowDialog("타이틀", txb, buttons);
                MessageBox.Show(tx1.ToString());
            };
            _btn33.Click += delegate
            {
                TextBlock txb = new TextBlock();
                txb.Background = Brushes.DarkOrange;
                txb.FontSize = 56;
                txb.Text = "박종명 마운드";
                txb.Width = 400;
                txb.Height = 250;
                //MessageBoxButton buttons = MessageBoxButton.OK;
                //MessageBoxButton buttons = MessageBoxButton.OKCancel;
                //MessageBoxButton buttons = MessageBoxButton.YesNo;
                MessageBoxButton buttons = MessageBoxButton.YesNo;
                var tx1 = TElementPopupWindow.ShowDialog("타이틀", txb, buttons);
                MessageBox.Show(tx1.ToString());
            };
            _btn34.Click += delegate
            {
                TextBlock txb = new TextBlock();
                txb.Background = Brushes.DarkOrange;
                txb.FontSize = 56;
                txb.Text = "박종명 마운드";
                txb.Width = 400;
                txb.Height = 250;
                //MessageBoxButton buttons = MessageBoxButton.OK;
                //MessageBoxButton buttons = MessageBoxButton.OKCancel;
                //MessageBoxButton buttons = MessageBoxButton.YesNo;
                MessageBoxButton buttons = MessageBoxButton.YesNoCancel;
                var tx1 = TElementPopupWindow.ShowDialog("타이틀", txb, buttons);
                MessageBox.Show(tx1.ToString());
            };


            _brdc.Child = null;
            Dispatcher.BeginInvoke(DispatcherPriority.Render,
                (Action)delegate
                {
                    if (_img.Source is BitmapSource tbs)
                    {
                        RenderOptions.SetEdgeMode(_img, EdgeMode.Aliased);
                        //RenderOptions.SetBitmapScalingMode(_img, BitmapScalingMode.NearestNeighbor);
                        _img.Width = tbs.PixelWidth;
                        _img.Height = tbs.PixelHeight;
                        var tx1 = TElementPopupWindow.ShowDialog("운명막이", _img);
                        MessageBox.Show(tx1.ToString());
                    }                    
                });            
        }

    }
}
