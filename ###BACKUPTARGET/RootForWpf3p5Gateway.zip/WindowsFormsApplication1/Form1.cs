﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Runtime.InteropServices;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            TxHelper.TestMap();
        }
    }







    [StructLayout(LayoutKind.Sequential)]
    public struct POINTSTRUCT
    {
        public int x;
        public int y;
        public POINTSTRUCT(int x, int y)
        {
            this.x = x;
            this.y = y;
        }
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct RECT
    {
        public int left;
        public int top;
        public int right;
        public int bottom;

        public RECT(int left, int top, int right, int bottom)
        {
            this.left = left;
            this.top = top;
            this.right = right;
            this.bottom = bottom;
        }

        public RECT(System.Drawing.Rectangle r)
        {
            this.left = r.Left;
            this.top = r.Top;
            this.right = r.Right;
            this.bottom = r.Bottom;
        }

        public static RECT FromXYWH(int x, int y, int width, int height)
        {
            return new RECT(x, y, x + width, y + height);
        }

        //public System.Drawing.Size Size
        //{
        //    get
        //    {
        //        return new System.Drawing.Size(this.right - this.left, this.bottom - this.top);
        //    }
        //}
    }

    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Auto, Pack = 4)]
    public class MONITORINFOEX
    {
        internal int cbSize = Marshal.SizeOf(typeof(MONITORINFOEX));
        internal RECT rcMonitor = new RECT();
        internal RECT rcWork = new RECT();
        internal int dwFlags = 0;
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 32)]
        internal char[] szDevice = new char[32];
    }

    public static class TxHelper
    {
        private const int MONITOR_DEFAULTTONEAREST = 0x00000002;

        [DllImport("user32.dll", SetLastError=true,
            CharSet=CharSet.Auto, EntryPoint="MonitorFromPoint")]
        private static extern IntPtr _MonitorFromPoint(POINTSTRUCT pt, int flags);


        [DllImport("user32.dll", SetLastError=true,
            CharSet = CharSet.Auto, EntryPoint = "GetMonitorInfo")]
        private static extern bool _GetMonitorInfo(HandleRef hmonitor, [In, Out]MONITORINFOEX info);


        public static void TestMap()
        {
            POINTSTRUCT pt = new POINTSTRUCT(10, 10);
            IntPtr monitor = _MonitorFromPoint(pt, MONITOR_DEFAULTTONEAREST);
            MONITORINFOEX info = new MONITORINFOEX();
            _GetMonitorInfo(new HandleRef(null, monitor), info);
        }
    }
}
