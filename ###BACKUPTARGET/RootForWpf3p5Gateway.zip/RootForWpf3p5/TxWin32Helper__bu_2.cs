﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.InteropServices;
using System.Windows;




namespace RootForWpf3p5
{
    //[StructLayout(LayoutKind.Sequential)]
    //internal struct _POINTSTRUCT
    //{
    //    public int x;
    //    public int y;
    //    public _POINTSTRUCT(int tx, int ty)
    //    {
    //        x = tx;
    //        y = ty;
    //    }
    //}

    //[StructLayout(LayoutKind.Sequential, CharSet = CharSet.Auto)]
    //internal struct _RECT
    //{
    //    public int left;
    //    public int top;
    //    public int right;
    //    public int bottom;

    //    public _RECT(int left, int top, int right, int bottom)
    //    {
    //        this.left = left;
    //        this.top = top;
    //        this.right = right;
    //        this.bottom = bottom;
    //    }

    //    public static _RECT FromXYWH(int x, int y, int width, int height)
    //    {
    //        return new _RECT(x, y, x + width, y + height);
    //    }
    //}

    //[StructLayout(LayoutKind.Sequential, CharSet = CharSet.Auto, Pack = 4)]
    //internal struct _MONITORINFOEX
    //{
    //    //public _MONITORINFOEX()
    //    //{
    //    //    cbSize = Marshal.SizeOf(typeof(_MONITORINFOEX));
    //    //    rcMonitor = new _RECT();
    //    //    rcWork = new _RECT();
    //    //    dwFlags = 0;
    //    //    szDevice = new char[32];
    //    //}
    //    public int cbSize;
    //    public _RECT rcMonitor;
    //    public _RECT rcWork;
    //    public int dwFlags;
    //    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 32)]
    //    public char[] szDevice;
    //}






    public static class TxWin32Helper
    {
        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Auto)]
        private struct _SrPoint
        {
            public int X;
            public int Y;
        }

        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Auto)]
        private struct _SrRect
        {
            public int Left;
            public int Top;
            public int Right;
            public int Bottom;
        }



        // size of a device name string
        private const int CCHDEVICENAME = 32;

        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Auto)]
        private struct _SrMonitorInfoEx
        {
            public int Size;

            public _SrRect Monitor;

            public _SrRect WorkArea;

            public uint Flags;

            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = CCHDEVICENAME)]
            public string DeviceName;

            public void Init()
            {
                this.Size = 40 + 2 * CCHDEVICENAME;
                this.DeviceName = string.Empty;
            }
        }



        private const int MONITOR_DEFAULTTONULL = 0x00000000;
        private const int MONITOR_DEFAULTTOPRIMARY = 0x00000001;
        private const int MONITOR_DEFAULTTONEAREST = 0x00000002;


        [DllImport("user32.dll", SetLastError = true,
            CharSet = CharSet.Auto, EntryPoint = "MonitorFromPoint")]
        private static extern IntPtr _MonitorFromPoint(_SrPoint pt, int flags);


        [DllImport("user32.dll", SetLastError = true,
            CharSet = CharSet.Auto, EntryPoint = "GetMonitorInfo")]
        private static extern bool _GetMonitorInfo(
            IntPtr hMonitor,
            [In, Out]_SrMonitorInfoEx info);


        public static Rect GetScreemBounds(double tx, double ty)
        {
            _SrPoint pt = new _SrPoint();
            pt.X = (int)tx;
            pt.Y = (int)ty;
            IntPtr monitor = _MonitorFromPoint(pt, MONITOR_DEFAULTTONEAREST);
            _SrMonitorInfoEx minfo = new _SrMonitorInfoEx();
            minfo.Init();
            //minfo.Size = Marshal.SizeOf(typeof(_SrMonitorInfoEx));
            if (_GetMonitorInfo(monitor, minfo))
            {
                //return new Rect(0, 0, info.rcMonitor.right, info.rcMonitor.bottom);
            }
            return Rect.Empty;
        }




        //public static void TestMap(double tx, double ty)
        //{
        //    _POINTSTRUCT pt = new _POINTSTRUCT((int)tx, (int)ty);
        //    IntPtr monitor = _MonitorFromPoint(pt, MONITOR_DEFAULTTONEAREST);
        //    _MONITORINFOEX info = new _MONITORINFOEX();
        //    if (_GetMonitorInfo(new HandleRef(null, monitor), info))
        //    {
        //    }
        //}
    }
}
