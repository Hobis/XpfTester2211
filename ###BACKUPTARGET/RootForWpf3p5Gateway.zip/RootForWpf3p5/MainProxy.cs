﻿using System;
using System.Collections.Generic;




namespace RootForWpf3p5
{
    public static class MainProxy
    {
        private static readonly Dictionary<string, Action> mDic = new Dictionary<string, Action>();

        public static void Add100(string tm, Action ta)
        {
            if (mDic.ContainsKey(tm)) return;
            mDic[tm] = ta;
        }

        public static void Call100(string tm)
        {
            if (mDic.ContainsKey(tm))
                mDic[tm].Invoke();
        }
    }
}
