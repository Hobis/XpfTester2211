﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.InteropServices;
using System.Windows;




namespace RootForWpf3p5
{
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Auto)]
    internal struct _SrPoint
    {
        internal _SrPoint(int tx, int ty)
        {
            X = tx;
            Y = ty;
        }

        internal int X;
        internal int Y;
    }

    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Auto)]
    internal struct _SrRect
    {
        internal _SrRect(int left, int top, int right, int bottom)
        {
            Left = left;
            Top = top;
            Right = right;
            Bottom = bottom;
        }

        internal int Left;
        internal int Top;
        internal int Right;
        internal int Bottom;
    }

    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Auto, Pack = 4)]
    internal struct _SrMonitorInfo
    {
        internal void InitOnce()
        {
            Size = Marshal.SizeOf(typeof(_SrMonitorInfo));
            Monitor = new _SrRect();
            Work = new _SrRect();
            Flags = 0;
            Device = new char[32];
        }

        internal int Size;
        internal _SrRect Monitor;
        internal _SrRect Work;
        internal int Flags;
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 32)]
        internal char[] Device;

        internal string Name
        {
            get
            {
                return new string(Device);
            }
        }
    }



    public static class TxWin32Helper
    {
        //// 기본값은 NULL
        //private const int MONITOR_DEFAULTTONULL = 0x00000000;
        //// 기본으로 기본
        //private const int MONITOR_DEFAULTTOPRIMARY = 0x00000001;
        // 가장 가까운 것으로 기본 설정
        private const int MONITOR_DEFAULTTONEAREST = 0x00000002;


        [DllImport("user32.dll", SetLastError = true,
            CharSet = CharSet.Auto, EntryPoint = "MonitorFromPoint")]
        private static extern IntPtr _MonitorFromPoint(_SrPoint pt, int flags);


        [DllImport("user32.dll", SetLastError = true,
            CharSet = CharSet.Auto, EntryPoint = "GetMonitorInfo")]
        private static extern bool _GetMonitorInfo(
            IntPtr hMonitor,
            ref _SrMonitorInfo info);


        public static Rect GetScreemBounds(double tx, double ty)
        {
            _SrPoint pt = new _SrPoint();
            pt.X = 99909;
            pt.Y = 99909;

            _SrMonitorInfo minfo = new _SrMonitorInfo();
            minfo.InitOnce();
            IntPtr pm = _MonitorFromPoint(pt, MONITOR_DEFAULTTONEAREST);

            if (_GetMonitorInfo(pm, ref minfo))
            {
                return new Rect(0, 0, minfo.Monitor.Right, minfo.Monitor.Bottom);
            }

            return Rect.Empty;
        }




        //public static void TestMap(double tx, double ty)
        //{
        //    _POINTSTRUCT pt = new _POINTSTRUCT((int)tx, (int)ty);
        //    IntPtr monitor = _MonitorFromPoint(pt, MONITOR_DEFAULTTONEAREST);
        //    _MONITORINFOEX info = new _MONITORINFOEX();
        //    if (_GetMonitorInfo(new HandleRef(null, monitor), info))
        //    {
        //    }
        //}
    }
}
