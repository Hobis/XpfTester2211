﻿using System.Windows.Controls;
using System.Windows;
using System.Windows.Controls.Primitives;
using System.Windows.Interop;
using System.Windows.Media;
using System.Windows.Input;




namespace RootForWpf3p5
{
    /// <summary>
    /// MainContainer.xaml에 대한 상호 작용 논리
    /// </summary>
    public sealed partial class MainContainer : UserControl
    {
        public MainContainer()
        {
            InitializeComponent();
            Loaded += ppLoaded;
        }


        private void ppLoaded(object tsd, RoutedEventArgs tea)
        {
            mTxb31.Clear();


            mBtn32.Click += delegate
            {
            };

            mBtn31.Click += delegate
            {
                MainProxy.Call100("Restart");
            };

            mRct31.MouseLeftButtonDown += delegate
            {
                _cmenu.IsOpen = true;
            };


            _cmenu = new ContextMenu();
            _cmenu.PlacementTarget = mRct31;
            _cmenu.Placement = PlacementMode.Top;
            MenuItem tmi = new MenuItem();
            tmi.Header = "프로그램 다시 시작";
            tmi.Click += delegate
            {
                MainProxy.Call100("Restart");
            };
            _cmenu.Items.Add(tmi);
            tmi = new MenuItem();
            tmi.Header = "프로그램 다시 시작";
            tmi.Click += delegate
            {
                MainProxy.Call100("Restart");
            };
            _cmenu.Items.Add(tmi);
            tmi = new MenuItem();
            tmi.Header = "프로그램 다시 시작";
            tmi.Click += delegate
            {
                MainProxy.Call100("Restart");
            };
            _cmenu.Items.Add(tmi);
            tmi = new MenuItem();
            tmi.Header = "프로그램 다시 시작";
            tmi.Click += delegate
            {
                MainProxy.Call100("Restart");
            };
            _cmenu.Items.Add(tmi);
            tmi = new MenuItem();
            tmi.Header = "프로그램 다시 시작";
            tmi.Click += delegate
            {
                MainProxy.Call100("Restart");
            };
            _cmenu.Items.Add(tmi);
            tmi = new MenuItem();
            tmi.Header = "프로그램 다시 시작";
            tmi.Click += delegate
            {
                MainProxy.Call100("Alert1");
            };
            _cmenu.Items.Add(tmi);
            tmi = new MenuItem();
            tmi.Header = "2222";
            tmi.Click += delegate
            {
                //MainProxy.Call100("Restart");


                //Brush brs = Brushes.Red.Clone();
                //brs.Opacity = 0.3;
                //Border tbd = new Border()
                //{
                //    HorizontalAlignment = HorizontalAlignment.Stretch,
                //    VerticalAlignment = VerticalAlignment.Stretch,
                //    Background = brs,
                //    Cursor = Cursors.Hand
                //};
                //mGrdrt.Children.Add(tbd);

                //var taw = ActualWidth;
                //var tah = ActualHeight;
                //MessageBox.Show(":");


                Point tpt = Mouse.GetPosition(this);
                //TxWin32Helper.TestMap(tpt.tx, tpt.ty);
                var tx1 = TxWin32Helper.GetScreemBounds(tpt.X, tpt.Y);
                var tx2 = "";
            };
            _cmenu.Items.Add(tmi);




            //WindowInteropHelper wih = new WindowInteropHelper(new Window());
            //var tx1 = Window.GetWindow(this);
            //var tx2 = Application.Current;
            //var tx3 = VisualTreeHelper.GetParent(this);
            //var tx4 = VisualTreeHelper.GetParent(tx3);
            //var tx5 = VisualTreeHelper.GetParent(tx4);


            //Window wnd = new Window();
            //wnd.Width = 400;
            //wnd.Height = 300;
            //wnd.WindowStartupLocation = WindowStartupLocation.CenterScreen;
            //wnd.ShowDialog();


            //MessageBox.Show("Message", "Caption", MessageBoxButton.OKCancel);


            
        }

        private ContextMenu _cmenu;

    }





}
