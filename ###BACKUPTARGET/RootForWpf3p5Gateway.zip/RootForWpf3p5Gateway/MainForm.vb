﻿Imports System
Imports RootForWpf3p5
Imports System.Windows.Forms
Imports System.Runtime.InteropServices




Public NotInheritable Class MainForm
    Public Sub New()
        ' 이 호출은 디자이너에 필요합니다.
        InitializeComponent()

        ' InitializeComponent() 호출 뒤에 초기화 코드를 추가하십시오.

    End Sub


    Protected Overrides Sub OnLoad(tea As EventArgs)
        MyBase.OnLoad(tea)

        Text = [GetType]().Namespace
        MinimumSize = Size


        MainProxy.Add100("Restart",
            Sub()
                Application.Restart()
            End Sub)

        MainProxy.Add100("Alert1",
            Sub()
                Dim tmbf As New MsgBoxForm()
                tmbf.SetText("확인", My.Resources.TextFile1)
                Dim tdr As DialogResult = tmbf.ShowDialog(Me)
            End Sub)
    End Sub


    Protected Overrides Sub OnShown(tea As System.EventArgs)
        MyBase.OnShown(tea)

        _ehrt.Visible = True


        HxHelper.TestMap()
    End Sub




End Class







<StructLayout(LayoutKind.Sequential)>
Public Structure _POINTSTRUCT
    Public x As Integer
    Public y As Integer
    Public Sub New(tx As Integer, ty As Integer)
        x = tx
        y = ty
    End Sub
End Structure


Public NotInheritable Class HxHelper
    Private Sub New()
    End Sub

    Private Const _MONITOR_DEFAULTTONEAREST As Integer = &H2

    <DllImport("user32.dll", SetLastError:=True,
        CharSet:=CharSet.Auto, EntryPoint:="MonitorFromPoint")>
    Private Shared Function _MonitorFromPoint(pt As _POINTSTRUCT, flags As Integer) As IntPtr
    End Function

    Public Shared Sub TestMap()
        Dim tx0 = New _POINTSTRUCT(100000, 100000)
        Dim tx1 = _MonitorFromPoint(tx0, _MONITOR_DEFAULTTONEAREST)
    End Sub
End Class



