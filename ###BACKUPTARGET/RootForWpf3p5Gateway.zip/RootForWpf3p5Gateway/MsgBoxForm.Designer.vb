﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class MsgBoxForm
    Inherits System.Windows.Forms.Form

    'Form은 Dispose를 재정의하여 구성 요소 목록을 정리합니다.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows Form 디자이너에 필요합니다.
    Private components As System.ComponentModel.IContainer

    '참고: 다음 프로시저는 Windows Form 디자이너에 필요합니다.
    '수정하려면 Windows Form 디자이너를 사용하십시오.  
    '코드 편집기를 사용하여 수정하지 마십시오.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.m_btnNo = New System.Windows.Forms.Button()
        Me.m_btnYes = New System.Windows.Forms.Button()
        Me.m_label = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'm_btnNo
        '
        Me.m_btnNo.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.m_btnNo.Cursor = System.Windows.Forms.Cursors.Hand
        Me.m_btnNo.Location = New System.Drawing.Point(213, 115)
        Me.m_btnNo.Name = "m_btnNo"
        Me.m_btnNo.Size = New System.Drawing.Size(75, 23)
        Me.m_btnNo.TabIndex = 2
        Me.m_btnNo.Text = "NO"
        Me.m_btnNo.UseVisualStyleBackColor = True
        '
        'm_btnYes
        '
        Me.m_btnYes.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.m_btnYes.Cursor = System.Windows.Forms.Cursors.Hand
        Me.m_btnYes.Location = New System.Drawing.Point(132, 115)
        Me.m_btnYes.Name = "m_btnYes"
        Me.m_btnYes.Size = New System.Drawing.Size(75, 23)
        Me.m_btnYes.TabIndex = 1
        Me.m_btnYes.Text = "YES"
        Me.m_btnYes.UseVisualStyleBackColor = True
        '
        'm_label
        '
        Me.m_label.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.m_label.AutoSize = True
        Me.m_label.BackColor = System.Drawing.SystemColors.Control
        Me.m_label.Font = New System.Drawing.Font("맑은 고딕", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.m_label.Location = New System.Drawing.Point(9, 9)
        Me.m_label.Margin = New System.Windows.Forms.Padding(0)
        Me.m_label.Name = "m_label"
        Me.m_label.Size = New System.Drawing.Size(46, 17)
        Me.m_label.TabIndex = 0
        Me.m_label.Text = "Label1"
        '
        'MsgBoxForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(300, 150)
        Me.Controls.Add(Me.m_label)
        Me.Controls.Add(Me.m_btnYes)
        Me.Controls.Add(Me.m_btnNo)
        Me.Font = New System.Drawing.Font("맑은 고딕", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "MsgBoxForm"
        Me.ShowInTaskbar = False
        Me.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "MsgBoxForm"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents m_btnNo As System.Windows.Forms.Button
    Friend WithEvents m_btnYes As System.Windows.Forms.Button
    Friend WithEvents m_label As System.Windows.Forms.Label
End Class
