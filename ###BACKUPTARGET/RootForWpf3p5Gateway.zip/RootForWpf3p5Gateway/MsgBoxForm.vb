﻿Imports System
Imports System.Drawing
Imports System.Windows.Forms


Public NotInheritable Class MsgBoxForm
    Public Sub New()
        ' 이 호출은 디자이너에 필요합니다.
        InitializeComponent()

        ' InitializeComponent() 호출 뒤에 초기화 코드를 추가하십시오.
        AutoSizeMode = AutoSizeMode.GrowAndShrink
        'tmbf.Text = "한석률 VS 장그레 시스템 1.40"
        'tmbf.SetText(My.Resources.TextFile1)
    End Sub

    Protected Overrides Sub OnLoad(tea As EventArgs)
        MyBase.OnLoad(tea)
    End Sub

    Public Sub SetText(ttit As String, tmsg As String)
        Text = ttit
        m_label.Text = tmsg
        Dim trct As Rectangle = m_label.Bounds
        Dim tcsz As New Size(trct.Width + 60, trct.Height + 60)
        ClientSize = tcsz
        Dim tpt As New Point(CInt((tcsz.Width / 2) - (trct.Width / 2)), trct.Top)
        m_label.Location = tpt
    End Sub

    Private Sub prBtnYesClick(tsd As Object, tea As EventArgs) Handles m_btnYes.Click
        DialogResult = DialogResult.Yes
        Close()
    End Sub

    Private Sub prBtnNoClick(tsd As Object, tea As EventArgs) Handles m_btnNo.Click
        DialogResult = DialogResult.No
        Close()
    End Sub

End Class