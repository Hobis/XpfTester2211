﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.InteropServices;
using System.Windows;
using System.Windows.Threading;
using System.Threading;
using System.Windows.Interop;
using System.Diagnostics;




namespace UdxWpfWindowTester
{
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Auto)]
    internal struct _SrPoint
    {
        internal _SrPoint(int tx, int ty)
        {
            X = tx;
            Y = ty;
        }

        internal int X;
        internal int Y;
    }

    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Auto)]
    internal struct _SrRect
    {
        internal _SrRect(int left, int top, int right, int bottom)
        {
            Left = left;
            Top = top;
            Right = right;
            Bottom = bottom;
        }

        internal int Left;
        internal int Top;
        internal int Right;
        internal int Bottom;
    }

    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Auto, Pack = 4)]
    internal struct _SrMonitorInfo
    {
        internal void InitOnce()
        {
            Size = Marshal.SizeOf(typeof(_SrMonitorInfo));
            Monitor = new _SrRect();
            Work = new _SrRect();
            Flags = 0;
            Device = new char[32];
        }

        internal int Size;
        internal _SrRect Monitor;
        internal _SrRect Work;
        internal int Flags;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 32)]
        internal char[] Device;

        //internal string Name
        //{
        //    get
        //    {
        //        return new string(Device);
        //    }
        //}
    }



    [Flags]
    internal enum _SetWindowPosFlags : uint
    {
        /// <summary>If the calling thread and the thread that owns the window are attached to different input queues, 
        /// the system posts the request to the thread that owns the window. This prevents the calling thread from 
        /// blocking its execution while other threads process the request.</summary>
        /// <remarks>SWP_ASYNCWINDOWPOS</remarks>
        AsynchronousWindowPosition = 0x4000,

        /// <summary>Prevents generation of the WM_SYNCPAINT message.</summary>
        /// <remarks>SWP_DEFERERASE</remarks>
        DeferErase = 0x2000,

        /// <summary>Draws a frame (defined in the window's class description) around the window.</summary>
        /// <remarks>SWP_DRAWFRAME</remarks>
        DrawFrame = 0x0020,

        /// <summary>Applies new frame styles set using the SetWindowLong function. Sends a WM_NCCALCSIZE message to 
        /// the window, even if the window's size is not being changed. If this flag is not specified, WM_NCCALCSIZE 
        /// is sent only when the window's size is being changed.</summary>
        /// <remarks>SWP_FRAMECHANGED</remarks>
        FrameChanged = 0x0020,

        /// <summary>Hides the window.</summary>
        /// <remarks>SWP_HIDEWINDOW</remarks>
        HideWindow = 0x0080,

        /// <summary>Does not activate the window. If this flag is not set, the window is activated and moved to the 
        /// top of either the topmost or non-topmost group (depending on the setting of the hWndInsertAfter 
        /// parameter).</summary>
        /// <remarks>SWP_NOACTIVATE</remarks>
        DoNotActivate = 0x0010,

        /// <summary>Discards the entire contents of the client area. If this flag is not specified, the valid 
        /// contents of the client area are saved and copied back into the client area after the window is sized or 
        /// repositioned.</summary>
        /// <remarks>SWP_NOCOPYBITS</remarks>
        DoNotCopyBits = 0x0100,

        /// <summary>Retains the current position (ignores X and Y parameters).</summary>
        /// <remarks>SWP_NOMOVE</remarks>
        IgnoreMove = 0x0002,

        /// <summary>Does not change the owner window's position in the Z order.</summary>
        /// <remarks>SWP_NOOWNERZORDER</remarks>
        DoNotChangeOwnerZOrder = 0x0200,

        /// <summary>Does not redraw changes. If this flag is set, no repainting of any kind occurs. This applies to 
        /// the client area, the nonclient area (including the title bar and scroll bars), and any part of the parent 
        /// window uncovered as a result of the window being moved. When this flag is set, the application must 
        /// explicitly invalidate or redraw any parts of the window and parent window that need redrawing.</summary>
        /// <remarks>SWP_NOREDRAW</remarks>
        DoNotRedraw = 0x0008,

        /// <summary>Same as the SWP_NOOWNERZORDER flag.</summary>
        /// <remarks>SWP_NOREPOSITION</remarks>
        DoNotReposition = 0x0200,

        /// <summary>Prevents the window from receiving the WM_WINDOWPOSCHANGING message.</summary>
        /// <remarks>SWP_NOSENDCHANGING</remarks>
        DoNotSendChangingEvent = 0x0400,

        /// <summary>Retains the current size (ignores the cx and cy parameters).</summary>
        /// <remarks>SWP_NOSIZE</remarks>
        IgnoreResize = 0x0001,

        /// <summary>Retains the current Z order (ignores the hWndInsertAfter parameter).</summary>
        /// <remarks>SWP_NOZORDER</remarks>
        IgnoreZOrder = 0x0004,

        /// <summary>Displays the window.</summary>
        /// <remarks>SWP_SHOWWINDOW</remarks>
        ShowWindow = 0x0040,
    }



    public static class TxWpfWin32Helper
    {
        #region "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ 1"
        //// 기본값은 NULL
        //private const int MONITOR_DEFAULTTONULL = 0x00000000;
        //// 기본으로 기본
        //private const int MONITOR_DEFAULTTOPRIMARY = 0x00000001;
        // 가장 가까운 것으로 기본 설정
        private const int _MONITOR_DEFAULTTONEAREST = 0x00000002;


        [DllImport("user32.dll", SetLastError = true,
            CharSet = CharSet.Auto, EntryPoint = "MonitorFromPoint")]
        private static extern IntPtr _MonitorFromPoint(_SrPoint pt, int flags);


        [DllImport("user32.dll", SetLastError = true,
            CharSet = CharSet.Auto, EntryPoint = "GetMonitorInfo")]
        private static extern bool _GetMonitorInfo(IntPtr hMonitor, ref _SrMonitorInfo info);




        public static Rect GetScreemBounds(double tx, double ty)
        {
            _SrPoint pt = new _SrPoint();
            pt.X = (int)tx;
            pt.Y = (int)ty;

            _SrMonitorInfo minfo = new _SrMonitorInfo();
            minfo.InitOnce();
            IntPtr pm = _MonitorFromPoint(pt, _MONITOR_DEFAULTTONEAREST);

            if (_GetMonitorInfo(pm, ref minfo))
            {
                //return new Rect(0, 0, minfo.Monitor.Right, minfo.Monitor.Bottom);
                return new Rect(0, 0, minfo.Work.Right, minfo.Work.Bottom);
            }

            return Rect.Empty;
        }


        public static Rect GetScreemBounds(Point pt)
        {
            return GetScreemBounds(pt.X, pt.Y);
        }
        #endregion




        #region "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ 2"
        [DllImport("user32.dll",
            SetLastError = true,
            CharSet = CharSet.Auto,
            EntryPoint = "GetWindowRect")]
        private static extern bool _GetWindowRect(IntPtr hWnd, out _SrRect lpRect);

        public static Rect GetWindowRect(IntPtr hWnd)
        {
            _SrRect rc = new _SrRect();
            if (_GetWindowRect(hWnd, out rc))
            {
                Rect trv = new Rect(
                    rc.Left, rc.Top,
                    rc.Right - rc.Left, rc.Bottom - rc.Top);
                return trv;
            }

            return Rect.Empty;
        }
        #endregion






        //#region "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ 3"
        //[DllImport("user32.dll", SetLastError = true,
        //    CharSet = CharSet.Auto, EntryPoint = "FindWindow")]
        //private static extern IntPtr _FindWindow(string lpClassName, string lpWindowName);


        //[DllImport("user32.dll", SetLastError = true,
        //    CharSet = CharSet.Auto, EntryPoint = "SetForegroundWindow")]
        //private static extern bool _SetForegroundWindow(IntPtr hWnd);


        //[DllImport("user32.dll", SetLastError = true,
        //    CharSet = CharSet.Auto, EntryPoint = "ShowWindowAsync")]
        //private static extern bool _ShowWindowAsync(IntPtr hWnd, int nCmdShow);


        //[DllImport("user32.dll", SetLastError = true,
        //    CharSet = CharSet.Auto, EntryPoint = "ShowWindowAsync")]
        //public static extern bool SetWindowPos(IntPtr hWnd, IntPtr hWndInsertAfter,
        //    int x, int y, int cx, int cy, _SetWindowPosFlags uFlags);



        //private const int SW_SHOWNORMAL = 1;
        //private const int SW_SHOWMINIMIZED = 2;
        //private const int SW_SHOWMAXIMIZED = 3;




        //private static bool m_bLoop = false;

        //private static void _FindCore()
        //{
        //    while (m_bLoop)
        //    {
        //        Thread.Sleep(100);
        //        IntPtr hp = _FindWindow(null, "마이크로소프트");                
        //        if (hp != IntPtr.Zero)
        //        {
        //            m_bLoop = false;
        //            var tx1 = GetWindowRect(hp);
        //            Debug.WriteLine("~~~~~~~~~~~~~" + tx1);
        //        }
        //        else
        //        {
        //            Debug.WriteLine("실패 반복 횟수");
        //        }
        //    }
        //}

        //public static void FindWnd()
        //{
        //    Action act = _FindCore;
        //    m_bLoop = true;
        //    act.BeginInvoke(null, null);
        //}

        //#endregion







        //public static void TestMap(double tx, double ty)
        //{
        //    _POINTSTRUCT pt = new _POINTSTRUCT((int)tx, (int)ty);
        //    IntPtr monitor = _MonitorFromPoint(pt, _MONITOR_DEFAULTTONEAREST);
        //    _MONITORINFOEX info = new _MONITORINFOEX();
        //    if (_GetMonitorInfo(new HandleRef(null, monitor), info))
        //    {
        //    }
        //}
    }
}
