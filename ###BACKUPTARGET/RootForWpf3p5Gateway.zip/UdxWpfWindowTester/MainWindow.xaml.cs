﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;
using System.Windows.Interop;
using System.Threading;




namespace UdxWpfWindowTester
{
    public sealed partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            Loaded += ppLoaded;
        }

        protected override void OnContentRendered(EventArgs tea)
        {
            base.OnContentRendered(tea);
            SizeToContent = SizeToContent.Manual;
            MinWidth = ActualWidth;
            MinHeight = ActualHeight;
            m_pnlrt.Width = double.NaN;
            m_pnlrt.Height = double.NaN;
        }


        private void ppLoaded(object tsd, RoutedEventArgs tea)
        {
            Loaded -= ppLoaded;
            Title = "Tester Overrides";
            //ppReLocate();
            
            //MessageBox.Show("마이크로소프트", "마이크로소프트");           
        }



        private void ppReLocate()
        {
            WindowInteropHelper twih = new WindowInteropHelper(this);
            var tx1 = TxWpfWin32Helper.GetWindowRect(twih.Handle);
            


            Rect frc = TxWpfWin32Helper.GetScreemBounds(Mouse.GetPosition(this));
            Rect rrc = RestoreBounds;
            //Rect rrc = new Rect(Left, Top, ActualWidth, ActualHeight);
            //Rect rrc = new Rect(Left, Top, MinWidth, MinHeight);

            double left, top;
            if (frc.Width > rrc.Width)
                left = (frc.Width - rrc.Width) - 30;
            else
                left = 0.0;

            if (frc.Height > rrc.Height)
                top = (frc.Height - rrc.Height) - 30;
            else
                top = 0.0;


            WindowState = WindowState.Normal;
            //Width = 400;
            //Height = 300;
            Dispatcher.BeginInvoke(DispatcherPriority.Render,
                (Action)delegate
                {
                    //Thread.Sleep(3000);
                    Left = left;
                    Top = top;
                });




            //Action tac = delegate
            //{
            //    while (true)
            //    {
            //        Thread.Sleep(100);
            //        Dispatcher.BeginInvoke(DispatcherPriority.Render,
            //            (Action)delegate
            //            {
            //                Left -= 0.1;
            //                Top -= 0.1;
            //            });
            //    }
            //};
            //tac.BeginInvoke(null, null);

        }



        private void button1_Click(object sender, RoutedEventArgs e)
        {
            ppReLocate();

        }



    }
}
