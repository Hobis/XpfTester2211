﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Windows;
using DevExpress.Xpf.Core;




namespace XpfTester__GridControl
{
    public sealed partial class MainApp : Application
    {
    }
}
