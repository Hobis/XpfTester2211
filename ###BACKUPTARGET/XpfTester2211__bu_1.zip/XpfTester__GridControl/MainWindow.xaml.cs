﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using DevExpress.Xpf.Core;
using DevExpress.Xpf.Editors;
using DevExpress.Xpf.Editors.Settings;




namespace XpfTester__GridControl
{
//    public enum Priority { Low, BelowNormal, Normal, AboveNormal, High }
//    public sealed class CRowItem
//    {
//        public int Num { get; set; }
//        public string NumStr
//        {
//            get
//            {
//                int tn = Num;
//                uint tx = TxNumHelper.NumDigits((uint)tn);
//                return Num.ToString().PadLeft((int)tx, '0');
//            }
//        }
//        public string Name { get; set; }
//        public Priority Priority { get; set; }
//    }



    public sealed partial class MainWindow : ThemedWindow
    {
        public MainWindow()
        {
            InitializeComponent();
            prGridColumnSettings();
            Loaded += prLoaded;
        }

        protected override void OnContentRendered(EventArgs tea)
        {
            base.OnContentRendered(tea);
            SizeToContent = SizeToContent.Manual;
            m_pnlrt.Width = double.NaN;
            m_pnlrt.Height = double.NaN;
        }

        private void prLoaded(object tsd, RoutedEventArgs tea)
        {
            Loaded -= prLoaded;
        }



        public TxRowItemCollection RowItems { get; private set; }

        private void prGridColumnSettings()
        {
            ComboBoxEditSettings tcbes = new ComboBoxEditSettings()
            {
                IsTextEditable = false,
                ItemsSource = new string[] { "박종명", "임헌진", "정희범", "이중호" }
            };
            //LookUpEditBase.SetupComboBoxSettingsEnumItemSource<Priority>(tcbes);
            m_gcName.EditSettings = tcbes;

            TextEditSettings tes = new TextEditSettings()
            {
                CharacterCasing = CharacterCasing.Upper,
                MaskType = MaskType.RegEx,
                Mask = "\\d+"
            };
            m_gcValue.EditSettings = tes;

            RowItems = TxRowItemCollection.CreateCollection();
            m_grd.ItemsSource = RowItems;
        }

    }
}
