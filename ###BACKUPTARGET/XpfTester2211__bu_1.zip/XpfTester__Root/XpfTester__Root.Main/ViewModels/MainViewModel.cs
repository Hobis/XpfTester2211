﻿using DevExpress.Mvvm.POCO;

namespace XpfTester__Root.Main.ViewModels
{
    public class MainViewModel
    {
        public static MainViewModel Create()
        {
            return ViewModelSource.Create(() => new MainViewModel());
        }
    }
}
