﻿using DevExpress.Xpf.Core;

namespace XpfTester__Root.Main
{
    public partial class MainWindow : ThemedWindow
    {
        public MainWindow()
        {
            InitializeComponent();
        }
    }
}
