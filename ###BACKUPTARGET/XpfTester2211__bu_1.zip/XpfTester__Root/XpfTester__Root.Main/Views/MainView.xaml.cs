﻿using System.Windows.Controls;

namespace XpfTester__Root.Main.Views
{
    public partial class MainView : UserControl
    {
        public MainView()
        {
            InitializeComponent();
        }
    }
}
