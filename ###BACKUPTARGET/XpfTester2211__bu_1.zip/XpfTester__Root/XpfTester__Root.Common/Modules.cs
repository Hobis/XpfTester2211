﻿namespace XpfTester__Root.Common
{
    public static class Modules
    {
        public static string Main { get { return "Main"; } }
        public static string Module1 { get { return "Module1"; } }
        public static string Module2 { get { return "Module2"; } }
    }
}
