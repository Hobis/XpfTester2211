﻿namespace XpfTester__Root.Common
{
    public interface INavigationItem
    {
        string Caption { get; }
    }
}
