﻿using DevExpress.Xpf.Editors;
using DevExpress.Xpf.Editors.Settings;
using System.Collections.ObjectModel;
using System.Windows.Controls;

namespace XpfTester__Root.Modules.Views
{
    public static class TxNumHelper
    {
        public static int NumDigits(int tn)
        {
            if ((tn > 0) && (tn <= int.MaxValue))
            {
                int tc = 1;
                while (tn >= 10)
                {
                    tn /= 10;
                    //trace(tn);
                    tc++;
                }
                return tc;
            }
            else
            {
                return 0;
            }
        }
    }


    public sealed class TxRowItem
    {
        public int Num { get; set; }
        public static int AllNum = 99999;
        public string NumStr
        {
            get
            {
                int tn = Num;
                int tx = TxNumHelper.NumDigits(AllNum);
                return Num.ToString().PadLeft((int)tx, '0');
            }
        }
        public string Name { get; set; }
        public string Age { get; set; }
        public string Job { get; set; }
        public string Value { get; set; }
    }

    public sealed class TxRowItemCollection : ObservableCollection<TxRowItem>
    {
        public static TxRowItemCollection CreateCollection()
        {
            TxRowItemCollection trv = new TxRowItemCollection();
            int li = 999999;
            TxRowItem.AllNum = li;
            for (int i = 0; i < li; i++)
            {
                trv.Add(
                    new TxRowItem()
                    {
                        Num = i + 1,
                        Name = "박종명",
                        Age = "37",
                        Job = "유통업",
                        Value = string.Empty
                    }
                );
            }

            return trv;
        }
    }


    public partial class ModuleView : UserControl
    {
        public ModuleView()
        {
            InitializeComponent();
            prGridColumnSettings();
        }


        public TxRowItemCollection RowItems { get; private set; }

        private void prGridColumnSettings()
        {
            ComboBoxEditSettings tcbes = new ComboBoxEditSettings()
            {
                IsTextEditable = false,
                ItemsSource = new string[] { "박종명", "임헌진", "정희범", "이중호" }
            };
            //LookUpEditBase.SetupComboBoxSettingsEnumItemSource<Priority>(tcbes);
            m_gcName.EditSettings = tcbes;

            TextEditSettings tes = new TextEditSettings()
            {
                CharacterCasing = CharacterCasing.Upper,
                MaskType = MaskType.RegEx,
                Mask = "\\d+"
            };
            m_gcValue.EditSettings = tes;

            RowItems = TxRowItemCollection.CreateCollection();
            m_grd.ItemsSource = RowItems;
        }
    }
}
